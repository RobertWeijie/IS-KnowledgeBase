t=0:0.001:1;
rad=t*pi;
n=6;
A=zeros(6,1001);
A(1,:)=(sin(rad)-rad.*cos(rad))/pi./(1-cos(rad));
A(2,:)=(rad-sin(rad).*cos(rad))/pi./(1-cos(rad));
for i=3:n
   A(i,:)=2*(sin(i*rad).*cos(rad)-i*cos(i*rad).*sin(rad))/i/pi/(i*i-1)./(1-cos(rad));
   end;
t=t*180;
plot(t,A(1,:),'r');hold on;
plot(t,A(2,:),'b');hold on;
plot(t,A(3,:),'g');hold on;
plot(t,A(4,:),'m');hold on;
plot(t,A(5,:), 'k');hold on;
grid on;
xlabel('�ȡ�');
ylabel('��n');
title('���������г���ֽ�ϵ��');