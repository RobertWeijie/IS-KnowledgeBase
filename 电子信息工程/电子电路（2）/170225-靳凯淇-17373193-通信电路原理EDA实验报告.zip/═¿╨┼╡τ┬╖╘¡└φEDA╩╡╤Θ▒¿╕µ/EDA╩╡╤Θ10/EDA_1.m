n=10;
u=0:0.05:14;
for i=0:n
    J=besselj(i,u);
    h=plot(u,J);
    set(h,'Color',[rand,rand,rand]);
    hold on;
end
xlabel('mf');
ylabel('Jn(mf)');
title('Bessel function');
grid on;