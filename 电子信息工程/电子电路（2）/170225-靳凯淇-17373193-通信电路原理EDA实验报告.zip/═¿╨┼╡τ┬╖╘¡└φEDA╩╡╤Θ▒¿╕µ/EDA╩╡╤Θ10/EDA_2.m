function[]=EDA_2(mf,wc,wf)
if mf<0
    error('please input mf>=0');
end
format long;
for i=0:(mf+1)
    J=abs(besselj(i,mf));
    stem([wc-i*wf,wc+i*wf],[J,J],'fill');
    s=num2str(J,2);
    h=text(wc-i*wf,J,s);
    set(h,'HorizontalAlignment','Center','VerticalAlignment','Bottom');
    h=text(wc+i*wf,J,s);
    set(h,'HorizontalAlignment','Center','VerticalAlignment','Bottom');
    hold on;
end
xlabel('��');
ylabel('A(��)');
title('��Ƶ����Ƶ�ʷ����ֲ�������');
grid on;
whitebg([0 0 0]);
hold off;
